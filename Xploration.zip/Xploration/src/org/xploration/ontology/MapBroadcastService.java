package org.xploration.ontology;

import jade.content.*;
import jade.util.leap.*;
import jade.core.*;

/**
* Protege name: MapBroadcastService
* @author ontology bean generator
* @version 2017/05/22, 22:38:38
*/
public class MapBroadcastService extends Service{ 

   /**
* Protege name: mapBroadcastInfo
   */
   private MapBroadcastInfo mapBroadcastInfo;
   public void setMapBroadcastInfo(MapBroadcastInfo value) { 
    this.mapBroadcastInfo=value;
   }
   public MapBroadcastInfo getMapBroadcastInfo() {
     return this.mapBroadcastInfo;
   }

}
