package org.xploration.ontology;

import jade.content.*;
import jade.util.leap.*;
import jade.core.*;

/**
* Protege name: CapsuleRegistrationService
* @author ontology bean generator
* @version 2017/05/22, 22:38:38
*/
public class CapsuleRegistrationService extends Service{ 

   /**
* Protege name: capsuleRegistrationInfo
   */
   private CapsuleRegistrationInfo capsuleRegistrationInfo;
   public void setCapsuleRegistrationInfo(CapsuleRegistrationInfo value) { 
    this.capsuleRegistrationInfo=value;
   }
   public CapsuleRegistrationInfo getCapsuleRegistrationInfo() {
     return this.capsuleRegistrationInfo;
   }

}
