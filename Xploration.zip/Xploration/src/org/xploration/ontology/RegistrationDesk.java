package org.xploration.ontology;

import jade.content.*;
import jade.util.leap.*;
import jade.core.*;

/**
* Protege name: RegistrationDesk
* @author ontology bean generator
* @version 2017/05/22, 22:38:38
*/
public class RegistrationDesk extends Service{ 

}
