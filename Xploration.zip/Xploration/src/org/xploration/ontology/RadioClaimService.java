package org.xploration.ontology;

import jade.content.*;
import jade.util.leap.*;
import jade.core.*;

/**
* Protege name: RadioClaimService
* @author ontology bean generator
* @version 2017/05/22, 22:38:38
*/
public class RadioClaimService extends Service{ 

   /**
* Protege name: claimCellInfo
   */
   private ClaimCellInfo claimCellInfo;
   public void setClaimCellInfo(ClaimCellInfo value) { 
    this.claimCellInfo=value;
   }
   public ClaimCellInfo getClaimCellInfo() {
     return this.claimCellInfo;
   }

}
